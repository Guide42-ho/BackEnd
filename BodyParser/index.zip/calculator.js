const express = require('express');
var bodyParser = require('body-parser')
const app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.get("/", (req, res)=>{
    res.sendFile(__dirname + '/index.html');

} );
app.post("/", (req,res)=>{
    // console.log(req.body); //JavaScropt Object
    // console.log(req.body.num1)
    var result = Number(req.body.num1) +Number(req.body.num2)
    res.send("เลขที่ออก" + result);
 });
 app.post("/bmiCalculator", (req, res) => {
    
    const heightInCm = Number(req.body.height); // Assume num2 is the height in cm
    const weightInKg = Number(req.body.weight); // Assume num1 is the weight in kg

   
    // Calculate BMI
    const bmi = weightInKg / (heightInCm * heightInCm);

    // Determine BMI category
    if (bmi < 18.5) {
        res.send("น้ำหนักต่ำเกณฑ์"); // Underweight
    } else if (bmi >= 18.5 && bmi <= 22.9) {
        res.send("สมส่วน"); // Normal weight
    } else if (bmi >= 23.0 && bmi <= 24.9) {
        res.send("น้ำหนักเกิน"); // Overweight
    } else if (bmi >= 25.0 && bmi <= 29.9) {
        res.send("อ้วน"); // Obese
    } else if (bmi >= 30) {
        res.send("โรคอ้วนอันตราย"); // Severely Obese
    } else {
        res.send("Unable to determine BMI category.");
    }
});

app.listen(3000, ()=> {
   console.log ("Server is running on port 3000");
});
